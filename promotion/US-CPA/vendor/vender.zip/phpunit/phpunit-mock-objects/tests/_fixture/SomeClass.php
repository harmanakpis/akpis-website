<?php
class SomeClass
{
    public function doSomething($a, $b)
    {
        return;
    }

    public function doSomethingElse($c)
    {
        return;
    }
}
