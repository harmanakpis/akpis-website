[![Latest Stable Version](https://img.shields.io/packagist/v/phpunit/phpunit-mock-objects.svg?style=flat-square)](https://packagist.org/packages/phpunit/phpunit-mock-objects)
[![Minimum PHP Version](https://img.shields.io/badge/php-%3E%3D%207.0-8892BF.svg?style=flat-square)](https://php.net/)
[![Build Status](https://img.shields.io/travis/sebastianbergmann/phpunit-mock-objects/master.svg?style=flat-square)](https://phpunit.de/build-status.html)

# phpunit-mock-objects

**phpunit-mock-objects** is the default mock object library for PHPUnit.
