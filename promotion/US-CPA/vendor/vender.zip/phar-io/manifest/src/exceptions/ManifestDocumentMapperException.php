<?php

namespace PharIo\Manifest;

class ManifestDocumentMapperException extends \RuntimeException implements Exception {
}
