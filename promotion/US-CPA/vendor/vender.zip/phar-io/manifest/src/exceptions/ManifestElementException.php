<?php

namespace PharIo\Manifest;

class ManifestElementException extends \RuntimeException implements Exception {
}
